let bullets;
let asteroids;
let ship;
let shipImage, bulletImage, particleImage;
let MARGIN = 40;
let gameState = "start"; // Возможные состояния: "start", "playing", "won", "gameOver";
let backgroundImage;
let gameMusic;

function preload() {
  bulletImage = loadImage('fire.png');
  shipImage = loadImage('main.png');
  particleImage = loadImage('particle.png');
	backgroundImage = loadImage('back.png');
	gameMusic = loadSound('gamemusic.mp3'); // Загружаем музыкальный файл
}

function setup() {
  createCanvas(800, 600);

  if (ship) { // Проверяем, существует ли игрок, и удаляем его, если да
    ship.remove();
  }

  ship = createSprite(width / 2, height / 2);
  ship.maxSpeed = 6;
  ship.friction = 0.98;
  ship.setCollider('circle', 0, 0, 20);

  ship.addImage('normal', shipImage);
  ship.addAnimation('thrust', 'fire.png', 'fire.png');
	ship.scale = 0.1; // Уменьшаем размер корабля в 5 раз

  asteroids = new Group();
  bullets = new Group();

  for (let i = 0; i < 8; i++) {
    let ang = random(360);
    let px = width / 2 + 1000 * cos(radians(ang));
    let py = height / 2 + 1000 * sin(radians(ang));
    createAsteroid(3, px, py);
  }
}

function draw() {
  background(backgroundImage);

  textAlign(CENTER);
  text('Controls: Arrow Keys + X', width / 2, 20);

  if (gameState === "start") {
    // Главное меню
    fill(255);
    textAlign(CENTER);
    textSize(32);
    text("Press 'P' to play", width / 2, height / 3);
  } else if (gameState === "playing") {
    // Игровой процесс
    for (let i = 0; i < allSprites.length; i++) {
      let s = allSprites[i];
      if (s.position.x < -MARGIN) s.position.x = width + MARGIN;
      if (s.position.x > width + MARGIN) s.position.x = -MARGIN;
      if (s.position.y < -MARGIN) s.position.y = height + MARGIN;
      if (s.position.y > height + MARGIN) s.position.y = -MARGIN;
    }

    asteroids.overlap(bullets, asteroidHit);

    ship.bounce(asteroids);

    if (keyDown(LEFT_ARROW))
      ship.rotation -= 4;
    if (keyDown(RIGHT_ARROW))
      ship.rotation += 4;
    if (keyDown(UP_ARROW)) {
      ship.addSpeed(0.2, ship.rotation);
      ship.changeAnimation('thrust');
    } else
      ship.changeAnimation('normal');

    if (keyWentDown('x')) {
      let bullet = createSprite(ship.position.x, ship.position.y);
      bullet.addImage(bulletImage);
      bullet.setSpeed(10 + ship.getSpeed(), ship.rotation);
      bullet.life = 30;
      bullets.add(bullet);
    }

    if (asteroids.length === 0) {
      gameState = "won";
    }
		if (!gameMusic.isPlaying()) {
      gameMusic.play(); // Воспроизводим музыку, если она не играет
      gameMusic.loop(); // Повторяем музыку бесконечно
    }
  } else if (gameState === "won") {
    // Экран победы
    fill(255);
    textAlign(CENTER);
    textSize(32);
    text("You Win!", width / 2, height / 3);
    text("Press 'R' to restart", width / 2, height / 3 + 50);
  } 
  drawSprites();
}

function createAsteroid(type, x, y) {
  let a = createSprite(x, y);
  let img = loadImage('conta.png');
  a.addImage(img);
  a.setSpeed(2.5 - (type / 2), random(360));
  a.rotationSpeed = 0.5;
  a.type = type;

  if (type == 2)
    a.scale = 0.6;
  if (type == 1)
    a.scale = 0.3;

  a.mass = 2 + a.scale;
  a.setCollider('circle', 0, 0, 50);
  asteroids.add(a);
  return a;
}

function asteroidHit(asteroid, bullet) {
  let newType = asteroid.type - 1;

  if (newType > 0) {
    createAsteroid(newType, asteroid.position.x, asteroid.position.y);
    createAsteroid(newType, asteroid.position.x, asteroid.position.y);
  }

  for (let i = 0; i < 10; i++) {
    let p = createSprite(bullet.position.x, bullet.position.y);
    p.addImage(particleImage);
    p.setSpeed(random(3, 5), random(360));
    p.friction = 0.95;
    p.life = 15;
  }

  bullet.remove();
  asteroid.remove();
}

function keyTyped() {
  if (key === 'p' && gameState === "start") {
    gameState = "playing";
  } else if (key === 'r' && (gameState === "won" || gameState === "gameOver")) {
    resetGame();
  }
}

function resetGame() {
  bullets.removeSprites();
  asteroids.removeSprites();
  setup(); // Запускаем функцию setup() заново после сброса игры
  gameState = "start";
}




